public class Node
{
    int data;
    Node left, right;
  
    public Node(int infor )
    {
        data = infor;
        left = right = null;
    }
}