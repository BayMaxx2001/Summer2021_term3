// ListNode.java: node in the linked list of trees, initially root node trees
class ListNode {
   public TreeNode hufftree;
   public ListNode next;
}